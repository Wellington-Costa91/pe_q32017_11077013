#include <stdio.h>

int main()
{
   int x, y;
   printf("Insira os valores de x e y \n");
   scanf("%d", &x);
   scanf("%d", &y);
   printf("A subtração dos números é: %d \n", (x - y));
   return 0;	
}
