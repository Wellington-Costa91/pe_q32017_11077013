#include <stdio.h>

int main()
{
	printf("Meu primeiro programa no Ubuntu do meu Computador \n");
	return 0 ;
}
