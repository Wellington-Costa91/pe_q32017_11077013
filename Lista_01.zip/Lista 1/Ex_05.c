#include<stdio.h>

int main()
{
   float x, y;
   printf("Insira os valores de x e y: \n");
   scanf("%f", &x);
   scanf("%f", &y);
   if(y != 0)
   {
      printf("O resultado da divisão é: %f \n", (x/y));
   }
   else
   {
      printf("Não é possível realizar divisão por 0!\n");
   }
   
   return 0;
}
