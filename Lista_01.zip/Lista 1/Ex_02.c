#include <stdio.h>

int  main()
{
	int x, y;
	printf("Insira dois valores: \n");	
	scanf ("%d", &x);
	scanf ("%d", &y);
	x = x + y;
	printf ("O resultado da soma é: %d \n", x);	
	return 0;
}
