#include <stdio.h>
#include <math.h>

int main()
{
   unsigned int x, y;
   printf("Insira os valores de x e y \n");
   scanf("%d", &x);
   scanf("%d", &y);
   x = pow (x, y);
   printf("O valor de x^y é: %d\n", x);
   return 0;
}
