#include <stdio.h>

int main()
{
   int x;
   printf("Insira o valor de x \n");
   scanf("%d", &x);
   for (int i = (x-1); i > 1; i--)
   {
      x *=i;
   }
   printf("O valor do fatorial do número é: %d \n", x);
   return 0;
}
