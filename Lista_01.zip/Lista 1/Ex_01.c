#include <stdio.h>

int main()
{
	int x;
	printf("Entre com o valor:  ");
	scanf("%d", &x);
	if (x % 2 == 0)
	{
		printf("Este número é par\n");
	}
	else
	{
		printf("Este número é ímpar\n");
	}
	return 0;
}

