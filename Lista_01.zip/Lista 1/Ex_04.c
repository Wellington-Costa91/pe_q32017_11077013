#include<stdio.h>

int main()
{
   int x, y;
   printf("Insira os valores e x e y: \n");
   scanf("%d", &x);
   scanf("%d", &y);
   printf("O produto dos valores inseridos é: %d \n", x*y);

   return 0;
}
