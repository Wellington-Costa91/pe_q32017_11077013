#include <stdio.h>
#include <stdlib.h>


int particiona(int *v, int inicio, int final){
	int esq, dir, pivo, aux;
	esq = inicio;
	dir = final;
	pivo = v[inicio];
	
	while(esq < dir){
	//avança posição esquerda
		while(v[esq] <= pivo){
			esq++;
		}
	//recua posição direita
		while(v[dir] > pivo){
			dir--;
		}
	//troca esquerda e direita
		if (esq < dir){
			aux = v[esq];
			v[esq] = v[dir];
			v[dir] = aux;
		}
	}
	v[inicio] = v[dir];
	v[dir] = pivo;
	return dir;
	
}



void quickSort(int *v, int inicio, int fim){
	int pivo;
	if (fim>inicio){
	//separo em 2 particoes
		pivo = particiona(v, inicio, fim);
		//chamo a funcao pelas metades
		quickSort(v, inicio, pivo-1);
		quickSort(v, pivo+1, fim);
	}
}


int main()
{
	int v[] = {23,4,67,-8,90,54,21};
	
	quickSort(v,0,6);
	
	for(int i = 0; i < 6; i++){
		printf("%d ", v[i]);
	}
	printf("\n");
	

	
	return 0;
}
