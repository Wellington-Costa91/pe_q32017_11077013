#include <stdio.h>

int main(){
	int ano;
	int mes;
	int dia;
	
	
	scanf("%d", &dia);
	scanf("%d", &mes);
	scanf("%d", &ano);
	
	int z = (((ano<<4)+mes)<<5)+dia;
	
	printf("dia %d\n", z%32);
	printf("mes %d\n", (z>>5)%16);
	printf("ano %d\n", z>>9);
	
	printf("dia %d\n", z&31);
	printf("mes %d\n", (z>>5)&15);
	printf("ano %d\n", z>>9);
	
	
	return 0;
	
}

/* Operadores:
	&, |, <<, >>
	E, ou, desloca para esquerda, desloca para direita
	
	*/
