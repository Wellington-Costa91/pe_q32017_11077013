#include <stdio.h>
#include <time.h>
#include <limits.h>

#define BIGNUM ULONG_MAX

typedef unsigned long int ulint;


ulint f1(ulint x)
{
	ulint compara = 1;
	ulint y = x;
	while(y > 1){
		y = y / 2;
		compara = compara*2;
		printf("%ld\n", compara);
	}
	
	if(compara == x){
		printf("É potencia de 2, %lu\n", compara);
	}
	
	else
	{
		printf("Não é potencia de 2, %lu\n", compara);
	}
	
}

ulint f2(ulint x)
{
	ulint f;
	//O v-1 inverte os bits zeros de v até encontrar o primeiro bit 1 e o resultado será a negação de todos os bits antes desse bit 1, incluindo esse bit.
	//v   = 00010000
	//v-1 = 00001111
	f = x && !(x & (x - 1)); 
	if (f == 1)
	{
		printf("É potencia de 2, %lu\n", f);
	}
	else 
	{
		printf("Não é potencia de 2, %lu\n", f);
	}
}


int somaBits(int valor1, int valor2)
{
	int mask = 0x0001; // mascara pra isolar os bits de cada passo
	int bitres = 0, carry = 0; // bit resultado e transporte
	int b1, b2; // bits isolados de cada operacao
	int result = 0; // variavel resultado
	
	for ( int i = 0; i < 32; i++ )
	{
	   // isola os bits
	   b1 = valor1 & mask;
	   b2 = valor2 & mask;
	   // calcula o bit resultado e o transporte
	   bitres = ( b1 ^ b2 ) ^ carry;
	   carry = ( b1 & b2 ) | ( b1 & carry ) | ( b2 & carry );
	   // seta o valor na variavel resultado
	   result += bitres;
	   // Verifica o overflow
	   if ( i == 31 ) { if (carry) { printf("ERRO"); }}
	   // avanca a mascara para pegar o proximo bit
	   mask <<= 1;
	}
	
	return result;
}


int main(void) {
	
	int x, y;
	scanf ("%d", &x);
	scanf("%d", &y);
	f1(x);
	f2(x);  
	int result = somaBits(2,3);
	printf("Resultado soma bit a bit= %d\n", result);
  return 0;
}
	

