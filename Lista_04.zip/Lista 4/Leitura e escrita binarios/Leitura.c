/*        Para leitura de arquivos texto usa-se a função fread.

result = fread (ponteiro_area_onde_armazenar_os_dados, tam_de_cada_elemento, nro_de_elementos, arq);

       A função retorna o número total de elementos lidos, que pode ser menor do que o que foi especificado na chamada da rotina.

// ************************************************************
//   Exemplo de uso de arquivo binário
//   Este programa lê um arquivo binário e imprime o seu
//   conteudo na tela.
// ************************************************************
*/
#include <stdio.h>

typedef struct data
{
	int dia;
	int mes;
	int ano;
}data;

void main()
{
  FILE *arq;
  data Vet[100];
  int result;
  int i;
  // Abre um arquivo BINÁRIO para LEITURA
  arq = fopen("aniversarios.bin", "rb");
  if (arq == NULL)  // Se houve erro na abertura
  {
     printf("Problemas na abertura do arquivo\n");
     return;
  }
  result = fread (&Vet[0], sizeof(data), 100, arq);
  printf("Nro de elementos lidos: %d\n", result);

  for (i=0; i<result; i++)
      printf("%d %d %d\n", Vet[i].dia, Vet[i].mes, Vet[i].ano);
  
  fclose(arq);
}

