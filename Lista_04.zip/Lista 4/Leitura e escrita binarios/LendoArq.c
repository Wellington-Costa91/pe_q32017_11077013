#include <stdio.h>

typedef struct data
{
	int dia;
	int mes;
	int ano;
}data;

void main()
{
  FILE *arq;
  data Vet[100];
  int result;
  int i;
  // Abre um arquivo BINÁRIO para LEITURA
  arq = fopen("Arqteste.bin", "rb");
  if (arq == NULL)  // Se houve erro na abertura
  {
     printf("Problemas na abertura do arquivo\n");
     return;
  }
  result = fread (&Vet[0], sizeof(data), 100, arq);
  printf("Nro de elementos lidos: %d\n", result);

  for (i=0; i<result; i++)
      printf("%d %d %d\n", Vet[i].dia, Vet[i].mes, Vet[i].ano);
  
  fclose(arq);
}
