/*       Para gravação de arquivos texto usa-se a função  fwrite.

Exemplo de fwrite:

// ************************************************************
//   Exemplo de uso de arquivo binário
//   Este programa grava um vetor em um arquivo binário 
//
// ************************************************************
*/


#include <stdio.h>

typedef struct data
{
	int dia;
	int mes;
	int ano;
}data;

void main()
{
    data Nivers[100];
    FILE *arq;
    int result;
    int i;

    arq = fopen("Arqteste.bin", "wb"); // Cria um arquivo binário para gravação 

    if (arq == NULL) // Se não conseguiu criar
    {
        printf("Problemas na CRIACAO do arquivo\n");
   	return;
    }
    
    
    for(int i = 0; i < 50; i++)
    {
    	Nivers[i].dia = 20; 
    	Nivers[i].mes = 3;
    	Nivers[i].ano = 1956;
    }
    
    // Grava 30 números do vetor a partir da posição 50 
    result = fwrite (&Nivers[0], sizeof(data), 50, arq);

    printf("Nro de elementos gravados: %d", result); 
    fclose(arq);

}
