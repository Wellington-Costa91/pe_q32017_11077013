/*
A string format é a formatação dos dados e pode conter:
%d, %u - número inteiro com ou sem sinal,
respectivamente
%c - caractere
%f, %lf - float e double
%s - string
%o, %x - octal e hexadecimal
*/



#include <stdio.h>
#include <time.h>
#include <limits.h>

#define BIGNUM ULONG_MAX

typedef unsigned long int ulint;



// algoritmo que pega um numero e divide por 8, versão normal e bit trick
//////////////////////////////////
/*ulint f1(ulint x)
{
  int div = 8;
  return x / div;
}

ulint f2(ulint x)
{
  return x >> 3;
}
/////////////////////////////////
*/



//algoritmo que verifica se um número é potencia de 2
//////////////////////////////////////////////////
/*ulint f1(ulint x)
{
	ulint compara = 1;
	ulint y = x;
	while(y > 1){
		y = y / 2;
		compara = compara*2;
	}
	
	if(compara == x){
		return 1;
	}
	
	else
	{
		return 0;
	}
	
}

ulint f2(ulint x)
{
	ulint f;
	//O v-1 inverte os bits zeros de v até encontrar o primeiro bit 1 e o resultado será a negação de todos os bits antes desse bit 1, incluindo esse bit.
	//v   = 00010000
	//v-1 = 00001111
	f = x && !(x & (x - 1)); 
	if (f == 1)
	{
		return 1;
	}
	else 
	{
		return 0;
	}
}
*////////////////////////////////////////////////////





int main(void) {
  
  clock_t tempo_init, tempo_fim;
  double tempo_gasto;
  ulint soma = 0;
  
  tempo_init = clock();
  for (int i=0; i<BIGNUM; i++) {
    soma += f1(i);
  }
  tempo_fim = clock();
  tempo_gasto = (double)(tempo_fim - tempo_init) / CLOCKS_PER_SEC;
  printf("Tempo gasto na versao normal: %lf\n", tempo_gasto);
  
  tempo_init = clock();
  for (int i=0; i<BIGNUM; i++) {
    soma += f2(i);
  }
  tempo_fim = clock();
  tempo_gasto = (double)(tempo_fim - tempo_init) / CLOCKS_PER_SEC;
  printf("Tempo gasto na versao bitwise: %lf\n", tempo_gasto);
  
  return 0;
}
	

