#include <stdio.h>

typedef struct aluno{
	char nome[100];
	int RA;
	float p1;
	float p2;
	float p3;
}aluno;



int main(){
	FILE *file1;
	FILE *file2;
	aluno alunos[50];
	float media[50];
	
	file1 = fopen("lista_alunos.txt", "r");
	file2 = fopen("media_alunos.txt","w");
	
	if (file1 == NULL){
		printf("NÃO FOI POSSIVEL LER O ARQUIVO");
		return 1;
	}
	
	for (int i = 0; i<50; i++){
		fscanf(file1, "%s %d %f %f %f", alunos[i].nome, &alunos[i].RA, &alunos[i].p1, &alunos[i].p2, &alunos[i].p3);
		media[i] = (alunos[i].p1 + alunos[i].p2 + alunos[i].p3)/3;
		printf("Media do aluno %d = %.1f\n", i, media[i]);
	}

	for (int i = 0; i<50; i++){
		fprintf(file2,"/%s / %d / %.1f \n", alunos[i].nome, alunos[i].RA, media[i]);
	}
	
	fclose(file1);
	fclose(file2);
	return 0;
}




