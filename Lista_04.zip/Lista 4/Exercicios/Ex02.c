#include <stdio.h>

typedef struct cronometro{
	int minuto;
	int segundo;
	int decimo;
}cronometro;

cronometro diferenca(cronometro t1, cronometro t2){
	int tempo1, tempo2, resto;
	tempo1 = t1.decimos + 100*t1.segundo + 60*100*t1.minuto;
	tempo2 = t2.decimos + 100*t2.segundo + 60*100*t2.minuto;
	printf("%d\n",tempo1);
	tempo1 = tempo2 - tempo1;
	printf("%d\n",tempo1);
	
	t1.minuto = tempo1/6000;
	resto = tempo1 % 6000;
	
	t1.segundo = resto/100;
	resto = resto % 100;
	
	t1.decimos = resto;
	return t1;
}


int main(){

	cronometro t1, t2, t3;
	scanf("%d %d %d", &(t1.minuto), &(t1.segundo), &(t1.decimos));
	scanf("%d %d %d", &(t2.minuto), &(t2.segundo), &(t2.decimos));
	
	
	printf("%dm %ds %d\n", t1.minuto, t1.segundo, t1.decimos);
	printf("%dm %ds %d\n", t2.minuto, t2.segundo, t2.decimos);
	
	t3 = diferenca(t1,t2);
	
	printf("%dm %ds %d\n", t3.minuto, t3.segundo, t3.decimos);
	
	return 0;
}
