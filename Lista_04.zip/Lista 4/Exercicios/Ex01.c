#include <stdio.h>
#include <math.h>

typedef struct ponto{

	float x;
	float y;
	float z;
}ponto;

float distancia(ponto p1, ponto p2){
	float resultado = 0;
	resultado +=  pow((p2.x - p1.x),2);
	resultado +=  pow((p2.y - p1.y),2);
	resultado +=  pow((p2.z - p1.z),2);
	resultado = sqrt(resultado);
	return resultado;
}

//PARA COMPILAR NÃO ESQUECER QUE DEVE SER "gcc -o Ex01 Ex01.c -lm"
int main(){
	
	ponto p1, p2;
	float result;
	result = pow((p1.x - p1.y),2);
	scanf("%f %f %f", &p1.x, &p1.y, &p1.z);
	scanf("%f %f %f", &(p2.x), &(p2.y), &(p2.z));
	result = distancia(p1,p2);
	
	printf("%.2f\n", result);
	
	return 0;
}
