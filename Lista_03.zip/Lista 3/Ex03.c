#include <stdio.h>
#include <stdlib.h>

int * juntaVetor(int *v1, int *v2)
{
	int *v = malloc(10*sizeof(int));
	for (int i=0; i < 5; i++)
	{
		v[i] = v1[i];
		v[i+5] = v2[i];
	}
	return v;
}

int *soma(int *v1, int *v2)
{
	int *v = malloc(5 * sizeof(int));
	for (int i = 0; i < 5; i++)
	{
		v[i] = v1[i] + v2[i];
	}
	return v;
}

int main()
{
	int *v = malloc(10*sizeof(int));
	int *somado = malloc(10*sizeof(int));
	int i;
	int v1[5];
	int v2[5];
		
	for (i = 0; i < 5; i++)	
	{
		scanf ("%d", &v1[i]);
	}
	
	for (i = 0; i < 5; i++)	
	{
		scanf ("%d", &v2[i]);
	}

	v = juntaVetor(v1, v2);
	somado = soma(v1, v2);

	 for(i = 0; i < 10; i++)
	 {
	 	printf("%d ", v[i]);
	 	if (i==9)
	 	{
	 		printf("\n");
	 	}
	 	
	 }
	 
	for (i = 0; i < 5; i++)	
	{
		printf("%d ", somado[i]);
	}
	
	 printf("\nFim \n");
	 free(v);
	return 0;
}
