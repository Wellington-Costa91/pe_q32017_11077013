#include <stdio.h>
#include <stdlib.h>


int ** fazTransposta(int **matriz)
{
	int i, j;
	int **resultado = malloc(sizeof(int)*3);
	for (i = 0; i < 3; i++)
	{
		resultado [i] = malloc(sizeof(int)*3);
	}
	
	for(i = 0; i < 3; i++)
	{
		for (j = 0; j < 3; j++)
		{
			resultado[i][j] = matriz[j][i];
		}
	}
	return resultado;
}

void imprime(int **matriz)
{
	int i, j;
	for(i = 0; i < 3; i++)
	{
		for (j = 0; j < 3; j++)
		{
			printf("%d", matriz[i][j]);
		}
		printf("\n");
	}
}

int main()
{
	int i, j;	
	int **matriz = malloc(sizeof(int *) * 3);
	int **transposta = malloc(sizeof(int *) * 3);
	for (i = 0; i < 3; i++)
	{
		matriz[i] = malloc(sizeof(int)*3);
		transposta[i] = malloc(sizeof(int) *3);
	}
	
	printf("Insira os valores da matriz 3x3\n");
	for(i = 0; i < 3; i++)
	{
		for (j = 0; j < 3; j++)
		{
			scanf("%d", &matriz[i][j]);
		}
	}
		
	transposta = fazTransposta(matriz);
	imprime(transposta);	
	return 0;
}
