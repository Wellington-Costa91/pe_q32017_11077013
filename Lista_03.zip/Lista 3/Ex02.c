#include <stdio.h>


int tamanhoPalavra(char *string)
{
	int tamanho = -1;
	
	for (int i = 0; i < 255; i++)
	{
		if (string[i] != '\0')
		{
			tamanho++;
		}
		else
		{
			return tamanho;
		}
	}
}


char * inverte(char *string)
{
	char b;
	char * invertida;
	int tamanho, i;
	tamanho = tamanhoPalavra(string);
	
	for (i = 0; i < tamanho; i++)
	{
		invertida[i] = string[tamanho-i-1]; 
	}
	return invertida;
}


int main()
{

	char string[255];
	fgets(string,255,stdin);
	
	int tamanho = tamanhoPalavra(string);
	
	printf("%d\n", tamanho);
	
	//invertida = inverte(string);

	//printf("%s\n", invertida);
	
	return 0;
}
