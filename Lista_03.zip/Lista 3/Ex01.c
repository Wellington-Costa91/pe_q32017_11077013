#include <stdio.h>

int contaVogal(char *palavra)
{

	char *vogais;
	vogais = "aeiou";
	int conta = 0;
	
	for (int i = 0; i < 255; i++)
	{
		if (palavra[i] != '\0')
		{
			for (int j = 0; j < 5; j++)
			{
				if (palavra[i] == vogais[j])
				{
					conta++;
				}
			}
		}
		else 
		{
			return conta;
		}
	}
}


int main()
{

	char entrada[255];
	fgets(entrada, 255, stdin);
		
	int qtdVogais = contaVogal(entrada);
	printf("%d vogais\n", qtdVogais);

	return 0;
}
