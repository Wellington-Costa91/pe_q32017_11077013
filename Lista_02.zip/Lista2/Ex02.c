#include<stdio.h>

int main()
{
	float x, y, z;
	printf("Insira os valores de base, altura e largura\n");	
	scanf("%f", &x);
	scanf("%f", &y);
	scanf("%f", &z);
	printf("O volume do sólido é %.2f\n", (x*y*z));
	return 0;
}
