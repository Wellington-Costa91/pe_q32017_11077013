#include <stdio.h>

int main()
{	
	unsigned int x;
	printf("Insira um número\n");
	scanf ("%d", &x);
	if (x % 2 == 0)
	{
		printf("O número é par\n");
	}
	else 
	{
		printf("O número é impar\n");
	}
	return 0;
}
