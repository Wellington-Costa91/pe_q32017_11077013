#include <stdio.h>

float soma (float x, float y)
{
	return (x + y);
}

float subtract (float x, float y)
{
	return (x - y);
}

float mult (float x, float y)
{
	return (x * y);
}

float div (float x, float y)
{
	if(y == 0)
	{
		printf("impossível dividir por zero");
		return 0;
	}
	else
	{
		return (x / y);
	}
}
int main()
{
	int op;
	float x, y;
	scanf("%d", &op);
	scanf("%f", &x);
	scanf("%f", &y);
	if (op == 1)
	{
		printf("%.2f\n", soma(x, y));
	}
	else if(op == 2)
	{
		printf("%.2f\n", subtract (x , y));
		
	}	
	else if (op == 3)
	{
		printf("%.2f\n",mult (x, y));
	}
	else if (op == 4)
	{
		printf("%.2f\n",div (x, y));
	}
	else
	{
	printf("Opção inválida\n");
	}

 return 0;
}
